using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FightingGameV5.Items
{ 
    public class Item
    {
        static string[] PossibleNames =
        {
            "Cheese", "Salmon Sandwich", "Bottle of Rivella", "Spicey Salmon Sandwich", "Toblerone", "Filet-O-Fish"
        };
        static Random random = new();
        public static string staticName;
        public static int Heals;
        public string getName()
        {
            return staticName;
        }
        public int getHeal(string ItemName)
        {
            switch (ItemName)
            {
                case "Cheese":
                    Heals = 25;
                    break;
                case "Salmon Sandwich":
                    Heals = 20;
                    break;
                case "Bottle of Rivella":
                    Heals = 15;
                    break;
                case "Spicey Salmon Sandwich":
                    Heals = 30;
                    break;
                case "Toblerone":
                    Heals = 35;
                    break;
                case "Filet-O-Fish":
                    Heals = 10;
                    break;
                default:
                    Heals = random.Next(5, 10);
                    break;
            }
            return Heals;
        }
        public void generateNewItem()
        {
            staticName = PossibleNames[random.Next(0, PossibleNames.Length)];
        }
    }
}