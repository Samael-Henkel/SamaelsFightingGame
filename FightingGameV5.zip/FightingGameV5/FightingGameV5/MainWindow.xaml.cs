﻿using FightingGameV5.ButtonFunctionality;
using FightingGameV5.Items;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FightingGameV5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SolidColorBrush blue = new(Color.FromRgb(0, 255, 255));
        SolidColorBrush orange = new(Color.FromRgb(255, 128, 0));
        Player player = new();
        Enemy enemy = new();
        ButtonFunctionalityClass buttonFunctionality = new();
        public BitmapImage RedMode = new(new Uri("RedHeart.png", UriKind.Relative));
        public BitmapImage BlueMode = new(new Uri("BlueHeart.png", UriKind.Relative));
        public Item items = new Item();
        double speed;
        string modes = "Normal";
        bool Continue = false;
        bool PlayerTurn = false;
        bool itemTabOpen = false;
        bool isMoving = false;
        bool ActMenuOpen = false;
        bool GameEnd = false;
        bool dealtDamage = false;
        public MainWindow()
        {
            InitializeComponent();
            // GameLogic(); added 03.10.2022, replaced 07.10.2022
        }
        //Did this on 30.09.2022
        public void Movement(object sender, RoutedEventArgs e)
        {
            /* double leftMargin = Soul.Margin.Left;
               double topMargin = Soul.Margin.Top;
               double rightMargin = Soul.Margin.Right;
               double bottomMargin = Soul.Margin.Bottom;
               Button clickedButton = sender as Button;
               string direction = Convert.ToString(clickedButton.Content);
               if (direction == "↑")
               {
                   topMargin -= 1;
                   bottomMargin += 1;
               }
               else if (direction == "↓")
               {
                   topMargin += 1;
                   bottomMargin -= 1;
               }
               else if (direction == "→")
               {
                   leftMargin += 1;
                   rightMargin -= 1;
               }
               else if (direction == "←")
               {
                   leftMargin -= 1;
                   rightMargin += 1;
               }
               Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
               Unnessesary due to Keyboard Controls working */
        }
        public void KeyboardMovement(Key e)
        {
            double leftMargin = Soul.Margin.Left;
            double topMargin = Soul.Margin.Top;
            double rightMargin = Soul.Margin.Right;
            double bottomMargin = Soul.Margin.Bottom;
            if (e == Key.W)
            {
                topMargin -= 2;
                bottomMargin += 2;
                if (topMargin < 10)
                {
                    topMargin = 10;
                    bottomMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                    isMoving = false;
                }
            }
            else if (e == Key.S)
            {
                topMargin += 2;
                bottomMargin -= 2;
                if (bottomMargin < 10)
                {
                    bottomMargin = 10;
                    topMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                    isMoving = false;
                }
            }
            if (e == Key.A)
            {
                leftMargin -= 2;
                rightMargin += 2;
                if (leftMargin < 10)
                {
                    leftMargin = 10;
                    rightMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                    isMoving = false;
                }
            }
            else if (e == Key.D)
            {
                leftMargin += 2;
                rightMargin -= 2;
                if (rightMargin < 10)
                {
                    rightMargin = 10;
                    leftMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                    isMoving = false;
                }
            }
            Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
        }
        // 03.10.2022
        public void GameControl(object Object, EventArgs e)
        {
            isMoving = false;
            if (Keyboard.IsKeyDown(Key.W) || Keyboard.IsKeyDown(Key.Up))
            {
                isMoving = true;
                KeyboardMovement(Key.W);
            }
            else if (Soul.Source == BlueMode)
            {
                KeyboardMovement(Key.S);
            }
            if (Keyboard.IsKeyDown(Key.A) || Keyboard.IsKeyDown(Key.Left))
            {
                isMoving = true;
                KeyboardMovement(Key.A);
            }
            if (Keyboard.IsKeyDown(Key.S) || Keyboard.IsKeyDown(Key.Down))
            {
                isMoving = true;
                KeyboardMovement(Key.S);
            }
            if (Keyboard.IsKeyDown(Key.D) || Keyboard.IsKeyDown(Key.Right))
            {
                isMoving = true;
                KeyboardMovement(Key.D);
            }
            obstaclePositionUpdate();
        }
        class Obstacle
        {
            static Random random = new();
            public int height = random.Next(50, 110); // Changed Height: Changed 06.10.2022
            public int width = 10;
            static string[] PossiblePositions = new string[]
            {
                "Top", "Bottom",
            };
            public string position = PossiblePositions[random.Next(0, PossiblePositions.Length)];
            public bool right = random.Next(0, 100) >= 50;
            public double speed; // Different Speeds for each obstacle: Added 05.10.2022 
        }
        DispatcherTimer TimeControl = new();

        int TimeSurvived = 0;
        bool Gamestart = true;
        bool OnlyOnce = true;
        Obstacle[] obstacle = { new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle() }; /// Support for multiple obstacles: Added 04.10.2022
        public void GameLogic()
        {
            GameEnd = false;
            int i = 0;
            TimeSurvived = 0;
            Random random = new();
            int FiftyFifty = random.Next(0, 100);
            if (FiftyFifty >= 50)            // Random Chance to be blue: Added 04.10.2022
            {
                Soul.Source = BlueMode;
            }
            else
            {
                Soul.Source = RedMode;
            }
            Soul.Visibility = Visibility.Visible;
            if (Gamestart)
            {
                string currentDir = Directory.GetCurrentDirectory();
                Uri EasyMode = new(currentDir + @"\EasyMode.mp3", UriKind.RelativeOrAbsolute); // Music: Added 10.10.2022, Fixed so that it actually works 11.10.2022
                Uri NormalMode = new(currentDir + @"\NormalMode.mp3", UriKind.RelativeOrAbsolute);
                Uri HardMode = new(currentDir + @"\HardMode.mp3", UriKind.RelativeOrAbsolute);
                Uri NoHitMode = new(currentDir + @"\NoHitMode.mp3", UriKind.RelativeOrAbsolute);
                switch (modes) // Difficulty Settings: added 07.10.2022
                {
                    case "Normal":
                        player.hp = 50;
                        mePlayer.Source = NormalMode;
                        speed = 1.2;
                        break;
                    case "Easy":
                        player.hp = 100;
                        mePlayer.Source = EasyMode;
                        speed = 0.8;
                        break;
                    case "Hard":
                        player.hp = 20;
                        mePlayer.Source = HardMode;
                        speed = 1.5;
                        break;
                    case "No Hit":
                        player.hp = 1;
                        mePlayer.Source = NoHitMode;
                        speed = 2.0;
                        break;
                    default:
                        break;
                }
                mePlayer.Play();
                mePlayer.MediaEnded += new RoutedEventHandler(Repeat);
                PlayerName.Content = NameOfthePlayer.Text;
                MainMenu.Visibility = Visibility.Hidden;
                player.maxhp = player.hp;
                player.TP = 0;
                TPBar.Height = player.TP * 2;
                TPContent.Content = player.TP + "% TP";
                HPContent.Content = player.hp + "/" + player.maxhp + " HP";
                Bar.Width = player.maxhp * 2;
                HPBar.Width = player.hp * 2;
                Soul.Visibility = Visibility.Visible;
                if (OnlyOnce)
                {
                    TimeControl.Tick += new EventHandler(GameControl);
                    TimeControl.Interval = new TimeSpan(25000); //Game now doesnt speed up every turn: Fixed 05.10.2022
                    OnlyOnce = false;
                }
                enemy = new Enemy();
                Gamestart = false;
                foreach (Button button in ItemGrid.Children) //Adding Items: Added 05.10.2022
                {
                    Item item = new Item();
                    item.generateNewItem();
                    button.Content = "* " + item.getName();
                }
            }
            foreach (Rectangle rectangle in AttackContainer.Children)
            {
                obstacle[i].speed = speed; // Speed now depends on Difficulty: Changed 11.10.2022
                if (i == 0)
                {
                    rectangle.Fill = blue;
                }
                else if (i == 4)
                {
                    rectangle.Fill = orange;
                }
                rectangle.Visibility = Visibility.Visible;
                i++;
            }
            i = 0;
            foreach (Rectangle rectangle in AttackContainer.Children)
            {
                double TopMargin = rectangle.Margin.Top;
                double LeftMargin = (FightBox.ActualWidth - 20) / 5 * (i + 1);
                double RightMargin = FightBox.ActualWidth - LeftMargin - rectangle.Width;
                double BottomMargin = rectangle.Margin.Bottom;
                rectangle.Margin = new Thickness(LeftMargin, TopMargin, RightMargin, BottomMargin);
                i++;
            }
            i = 0;
            PlayerTurnText.Visibility = Visibility.Hidden;
            Soul.Margin = new Thickness(242, 95, 242, 95);
            TimeControl.Start();
        }
        public void obstaclePositionUpdate()
        {
            int i = 0;
            foreach (Rectangle rectangle in AttackContainer.Children)
            {
                double leftMargin = rectangle.Margin.Left;
                double topMargin = rectangle.Margin.Top;
                double rightMargin = rectangle.Margin.Right;
                double bottomMargin = rectangle.Margin.Bottom;
                if(enemy.spareprog >= 100)
                {
                    speed = 0.5;
                    obstacle[i].speed = speed;
                }
                if (player.hp > 0 && !GameEnd)
                {
                    if ((leftMargin < Soul.Margin.Left + Soul.ActualWidth && leftMargin + rectangle.Width > Soul.Margin.Left && topMargin <= FightBox.ActualHeight - Soul.Margin.Bottom && obstacle[i].position == "Bottom") || (leftMargin < Soul.Margin.Left + Soul.ActualWidth && leftMargin + rectangle.Width > Soul.Margin.Left && bottomMargin <= FightBox.ActualHeight - Soul.Margin.Top && obstacle[i].position == "Top")) // Collision Detection: Added 04.10.2022, Improved 07.10.2022
                    {
                        if (player.BlockableAtks > 0)
                        {
                            player.BlockableAtks--;
                        }
                        else if (rectangle.Fill == blue && !isMoving) // Blue stop signs: Added 06.10.2022
                        {
                            player.hp -= 0;
                        }
                        else if (rectangle.Fill == orange && isMoving)
                        {
                            player.hp -= 0;
                        }
                        else
                        {
                            player.hp--;
                            if (player.hp < 0)
                            {
                                player.hp = 0;
                            }
                            HPBar.Width = 2 * player.hp;
                            HPContent.Content = player.hp + "/" + player.maxhp + " HP";
                        }
                    }
                    if (obstacle[i].position == "Bottom")
                    {
                        bottomMargin = 10;
                        topMargin = FightBox.ActualHeight - 10 - rectangle.ActualHeight;
                    }
                    else if (obstacle[i].position == "Top")
                    {
                        topMargin = 10;
                        bottomMargin = FightBox.ActualHeight - 10 - rectangle.ActualHeight;
                    }
                    if (obstacle[i].right)
                    {
                        if (rightMargin <= 10)
                        {
                            leftMargin -= obstacle[i].speed;
                            rightMargin += obstacle[i].speed;
                            obstacle[i] = new Obstacle();
                            obstacle[i].right = false;
                            obstacle[i].speed = speed;
                            rectangle.Width = obstacle[i].width;
                            rectangle.Height = obstacle[i].height;
                        }
                        else
                        {
                            leftMargin += obstacle[i].speed;
                            rightMargin -= obstacle[i].speed;
                        }
                    }
                    else
                    {
                        if (leftMargin <= 10)
                        {
                            leftMargin += obstacle[i].speed;
                            rightMargin -= obstacle[i].speed;
                            obstacle[i] = new Obstacle();
                            obstacle[i].right = true;
                            obstacle[i].speed = speed;
                            rectangle.Width = obstacle[i].width;
                            rectangle.Height = obstacle[i].height;
                        }
                        else
                        {
                            leftMargin -= obstacle[i].speed;
                            rightMargin += obstacle[i].speed;
                        }
                    }
                }
                else if (player.hp <= 0 && !GameEnd) //End of Game added 04.10.2022
                {
                    TimeControl.Stop();
                    mePlayer.Stop();
                    Soul.Source = new BitmapImage(new Uri("RedHeartShattered.png", UriKind.Relative));
                    GameEnd = true;
                    MainMenu.Visibility = Visibility.Visible;
                    Gamestart = true;
                    MessageBox.Show("Gane Over", "You died");
                }
                rectangle.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
                i++;
            }
            if (!GameEnd)
            {
                TimeSurvived += 25000;
                if (mePlayer.Position == TimeSpan.MaxValue)
                {
                    Repeat(new Object(), new EventArgs());
                }
            }
            if (TimeSurvived >= 100000000)
            {
                TimeControl.Stop();
                if (enemy.spareprog < 100)
                {
                    WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_normalFace.png", UriKind.Relative));
                }
                foreach (Rectangle rectangle in AttackContainer.Children)
                {
                    rectangle.Visibility = Visibility.Hidden;
                }
                Soul.Visibility = Visibility.Hidden;
                PlayerTurnText.Visibility = Visibility.Visible;
                PlayerTurn = true;
            }
        }
        //04.10.2022
        class Player
        {
            public int hp = 50;
            public int maxhp = 50; // Maximum HP: Added 07.10.2022
            public int atk = 20;
            public int def = 20;
            public string Name = "CHARA";
            public bool isDef = false; // Is Defending and blocking Attacks: Added 05.10.2022
            public int BlockableAtks = 0;
            public int TP = 0; // Tension Points: Added 05.10.2022
        }
        class Enemy
        {
            public int hp = 200;
            public int atk = 10;
            public int def = 10;
            public int spareprog = 0; // Enemy now spareable: Added 06.10.2022
        }
        public void FightButton(object sender, RoutedEventArgs e) // Every Action (exept sparing) now needs to be continued by pressing "Z": Added 07.10.2022
        {
            if (PlayerTurn && !GameEnd && !itemTabOpen && !ActMenuOpen)
            {
                int hpBefore = enemy.hp;
                enemy.hp = buttonFunctionality.Fight(player.atk, enemy.def, enemy.hp);
                if (enemy.hp <= 0)
                {
                    WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_DeathFace.png", UriKind.Relative));
                    ActGrid.Visibility = Visibility.Hidden;
                    PlayerTurnText.Visibility = Visibility.Visible;
                    PlayerTurnText.Text = "YOU WON: You gained 32 EXP and 76 G";
                    mePlayer.Stop();
                }
                else
                {
                    WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_hitFace.png", UriKind.Relative));
                    ActGrid.Visibility = Visibility.Hidden;
                    PlayerTurnText.Visibility = Visibility.Visible;
                    PlayerTurnText.Text = "* You dealt " + (hpBefore - enemy.hp) + " Damage";
                    DialogueBox.Visibility = Visibility.Visible;
                    DialogueText.Text = "Oh, dangit, that hurt!";
                    PlayerTurn = false;
                    Continue = true;
                    dealtDamage = true;
                }
            }
        }
        //05.10.2022
        public void DefendButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd && !itemTabOpen && !ActMenuOpen)
            {
                if (!player.isDef)
                {
                    player.isDef = true;
                    player.BlockableAtks = 25;
                }
                player.TP = buttonFunctionality.defendTP(player.TP, player.def);
                TPBar.Height = player.TP * 2;
                TPContent.Content = Convert.ToString(player.TP) + "% TP";
                PlayerTurn = false;
                PlayerTurnText.Visibility = Visibility.Visible;
                PlayerTurnText.Text = "* You defended, and gained some TP in the process.";
                DialogueBox.Visibility = Visibility.Visible;
                if (enemy.spareprog < 100)
                {
                    DialogueText.Text = "Hiding behind a defend wont make you win!";
                }
                else
                {
                    DialogueText.Text = "...friend?";
                }
                Continue = true;
            }
        }
        public void ItemButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd && !ActMenuOpen)
            {
                if (!itemTabOpen)
                {
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    ItemGrid.Visibility = Visibility.Visible;
                    itemTabOpen = true;
                }
                else if (itemTabOpen)
                {
                    PlayerTurnText.Visibility = Visibility.Visible;
                    ItemGrid.Visibility = Visibility.Hidden;
                    itemTabOpen = false;
                }
                else
                {
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    ItemGrid.Visibility = Visibility.Visible;
                    itemTabOpen = true;
                }
            }
        }
        public void healing(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string HealingItem = Convert.ToString(button.Content);
            HealingItem = HealingItem.Substring(2);
            int hpBefore = player.hp;
            player.hp += items.getHeal(HealingItem);
            if (player.hp > player.maxhp)
            {
                player.hp = player.maxhp;
            }
            HPBar.Width = player.hp * 2;
            HPContent.Content = Convert.ToString(player.hp) + "/" + player.maxhp + " HP";
            button.Visibility = Visibility.Collapsed;
            ItemGrid.Visibility = Visibility.Hidden;
            PlayerTurn = false;
            itemTabOpen = false; // itemTabOpen bug: Fixed 06.10.2022
            PlayerTurnText.Visibility = Visibility.Visible;
            PlayerTurnText.Text = "* You consumed the " + HealingItem + ". " + (player.hp - hpBefore) + " HP restored.";
            DialogueBox.Visibility = Visibility.Visible;
            if (enemy.spareprog < 100)
            {
                DialogueText.Text = "You are gonna run out of items sometime!";
            }
            else
            {
                DialogueText.Text = "May i have some?";
            }
            Continue = true;
        }
        //06.10.2022
        public void ActButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd && !itemTabOpen)
            {
                if (!ActMenuOpen)
                {
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    ActGrid.Visibility = Visibility.Visible;
                    ActMenuOpen = true;
                }
                else if (ActMenuOpen)
                {
                    PlayerTurnText.Visibility = Visibility.Visible;
                    ActGrid.Visibility = Visibility.Hidden;
                    ActMenuOpen = false;
                }
                else
                {
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    ActGrid.Visibility = Visibility.Visible;
                    ActMenuOpen = true;
                }
            }
        }
        public void Acting(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string action = Convert.ToString(button.Content);
            action = action.Substring(2);
            switch (action)
            {
                case "Check":
                    {
                        ActGrid.Visibility = Visibility.Hidden;
                        PlayerTurnText.Visibility = Visibility.Visible;
                        PlayerTurnText.Text = "* Windows Presentation Foundation - " + enemy.hp + " HP, " + enemy.atk + " ATK, " + enemy.def + " DEF";
                        DialogueBox.Visibility = Visibility.Visible;
                        if (enemy.spareprog < 100)
                        {
                            DialogueText.Text = "Hey, checking is basically useless!";
                        }
                        else
                        {
                            DialogueText.Text = "...friend?";
                        }
                        PlayerTurn = false;
                        ActMenuOpen = false;
                        Continue = true;
                        break;
                    }
                case "Work harder":
                    {
                        enemy.spareprog += 10;
                        ActGrid.Visibility = Visibility.Hidden;
                        PlayerTurnText.Visibility = Visibility.Visible;
                        PlayerTurnText.Text = "You worked harder... You understand now more of WPF";
                        DialogueBox.Visibility = Visibility.Visible;
                        if(enemy.spareprog < 100)
                        {
                            DialogueText.Text = "Good attempt. Try harder next time!";
                        } else
                        {
                            DialogueText.Text = "Good Job... friend?";
                        }
                        PlayerTurn = false;
                        ActMenuOpen = false;
                        Continue = true;
                        break;
                    }
                case "Tension Heal (30%)":
                    {
                        if (player.TP >= 30)
                        {
                            player.TP -= 30;
                            TPBar.Height = player.TP * 2;
                            TPContent.Content = player.TP + "% TP";
                            player.hp += items.getHeal("Tension Heal (30%)");
                            if (player.hp > player.maxhp)
                            {
                                player.hp = player.maxhp;
                            }
                            HPBar.Width = player.hp * 2;
                            HPContent.Content = player.hp + "/" + player.maxhp + " HP";
                            ActGrid.Visibility = Visibility.Hidden;
                            PlayerTurnText.Visibility = Visibility.Visible;
                            PlayerTurnText.Text = "* You healed yourself using your Tension Points";
                            DialogueBox.Visibility = Visibility.Visible;
                            DialogueText.Text = "Huh, seems im good at dealing damage";
                            PlayerTurn = false;
                            ActMenuOpen = false;
                            Continue = true;
                        }
                        break;
                    }
                case "Special Attack (50%)":
                    {
                        if (player.TP >= 50)
                        {
                            player.TP -= 50;
                            TPBar.Height = player.TP * 2;
                            TPContent.Content = player.TP + "% TP";
                            int hpBefore = enemy.hp;
                            enemy.hp = buttonFunctionality.specatk(player.TP, player.atk, enemy.def, enemy.hp);
                            if (enemy.hp <= 0)
                            {
                                WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_DeathFace.png", UriKind.Relative));
                                ActGrid.Visibility = Visibility.Hidden;
                                PlayerTurnText.Text = "YOU WON: You gained 32 EXP and 76 G";
                                mePlayer.Stop();
                            }
                            else
                            {
                                WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_hitFace.png", UriKind.Relative));
                                ActGrid.Visibility = Visibility.Hidden;
                                PlayerTurnText.Visibility = Visibility.Visible;
                                PlayerTurnText.Text = "* You dealt " + (hpBefore - enemy.hp) + " Damage";
                                DialogueBox.Visibility = Visibility.Visible;
                                DialogueText.Text = "Oh, dangit, that hurt!";
                                PlayerTurn = false;
                                Continue = true;
                                dealtDamage = true;
                            }
                        }
                        break;
                    }
            }
        }
        public void SpareButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd && !ActMenuOpen && !itemTabOpen)
            {
                if (enemy.spareprog == 100)
                {
                    GameEnd = true;
                    PlayerTurnText.Text = "* YOU WON: You gained 0 EXP and 23 G";
                    mePlayer.Stop();
                }
                else
                {
                    PlayerTurnText.Text = "* You feel like you're gonna have to google everything.";
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    GameLogic();
                }
            }
        }
        // 07.10.2022
        public void keyboardContinue(object sender, KeyboardEventArgs e)
        {
            if (Continue)
            {
                if (Keyboard.IsKeyDown(Key.Z))
                {
                    if (dealtDamage)
                    {
                        dealtDamage = false;
                        WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_aggresiveFace.png", UriKind.Relative));
                    }
                    else if (enemy.spareprog == 100)
                    {
                        WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_HappyFace.png", UriKind.Relative));
                    }
                    else
                    {
                        WindowsPresentationFoundation.Source = new BitmapImage(new Uri("WPF_normalFace.png", UriKind.Relative));
                    }
                    PlayerTurnText.Text = "* You feel like you're gonna have to google everything.";
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    DialogueBox.Visibility = Visibility.Hidden;
                    Continue = false;
                    GameLogic();
                }
            }
        }
        public void ModeButton(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            modes = (string)button.Content;
            GameLogic();
        }
        // 10.10.2022
        private void Repeat(object sender, EventArgs e)
        {
            string currentDir = Directory.GetCurrentDirectory();
            Uri EasyMode = new(currentDir + @"\EasyMode.mp3", UriKind.RelativeOrAbsolute);
            Uri NormalMode = new(currentDir + @"\NormalMode.mp3", UriKind.RelativeOrAbsolute);
            Uri HardMode = new(currentDir + @"\HardMode.mp3", UriKind.RelativeOrAbsolute);
            Uri NoHitMode = new(currentDir + @"\NoHitMode.mp3", UriKind.RelativeOrAbsolute);
            switch (modes) // Difficulty Settings: added 07.10.2022
            {
                case "Normal":
                    mePlayer.Source = NormalMode;
                    break;
                case "Easy":
                    mePlayer.Source = EasyMode;
                    break;
                case "Hard":
                    mePlayer.Source = HardMode;
                    break;
                case "No Hit":
                    mePlayer.Source = NoHitMode;
                    break;
                default:
                    break;
            }
            mePlayer.Play();
        }
    }
}