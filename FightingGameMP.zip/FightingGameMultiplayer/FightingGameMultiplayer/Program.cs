﻿using System;
using System.Collections.Generic;

namespace FightingGameMultiplayer
{
    class Program
    {
        static int ThingsKilled = 0;
        static int ThingsSpared = 0;
        static int NumberOfPlayers = 1;
        static int EverybodyDown = 0;
        static List<Player> FunGang;
        public static TPContainer ATPContainer = new();
        public static Enemy enemy = new();
        static bool doSomething = false;
        static void Main()
        {
            Console.WriteLine("Hello.");
            Console.WriteLine("I want to play a game.");
            Console.WriteLine("A strange game.");
            Console.WriteLine("There are multiple ways to play this game.");
            Console.WriteLine("Killing or sparing.");
            Console.WriteLine("Before we begin, i need to know some things.");
            bool isNumber = false;
            string EnterANumber;
            while (!isNumber)
            {
                Console.WriteLine("How many players are there?");
                EnterANumber = Console.ReadLine();
                try
                {
                    NumberOfPlayers = Int32.Parse(EnterANumber);
                    isNumber = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine("That is Not A Number");
                }
            }
            FunGang = new List<Player>();
            for (int i = 1; i <= NumberOfPlayers; i++)
            {
                var player = new Player();
                Console.WriteLine("Choose a Name for Player " + i);
                player.name = Console.ReadLine();
                player.playerID = i;
                FunGang.Add(player);
            }
            foreach (Player player in FunGang)
            {
                Console.WriteLine(player.name + " " + player.playerID);
                bool TypeExists = false;
                while (!TypeExists)
                {
                    Console.WriteLine("Give " + player.name + " a class. [Murderer/Fighter/Neutral/Healer/Pacifist]");
                    string className = Console.ReadLine().ToLower();
                    switch (className)
                    {
                        case ("fighter"):
                        case ("1"):
                            player.maxhp = 120;
                            player.hp = 120;
                            player.atk = 12;
                            player.def = 8;
                            player.ClassName = "fighter";
                            TypeExists = true;
                            break;
                        case ("healer"):
                        case ("2"):
                            player.maxhp = 80;
                            player.hp = 80;
                            player.atk = 8;
                            player.def = 12;
                            player.ClassName = "healer";
                            TypeExists = true;
                            break;
                        case ("neutral"):
                        case ("3"):
                            player.maxhp = 100;
                            player.hp = 100;
                            player.atk = 10;
                            player.def = 10;
                            player.ClassName = "neutral";
                            TypeExists = true;
                            break;
                        case ("murderer"):
                        case ("4"):
                            player.maxhp = 150;
                            player.hp = 150;
                            player.atk = 15;
                            player.def = 5;
                            player.ClassName = "murderer";
                            player.canSpare = false;
                            TypeExists = true;
                            break;
                        case ("pacifist"):
                        case ("5"):
                            player.maxhp = 50;
                            player.hp = 50;
                            player.atk = 5;
                            player.def = 15;
                            player.ClassName = "pacifist";
                            player.canFight = false;
                            TypeExists = true;
                            break;
                        default:
                            Console.WriteLine("Unknown Class");
                            break;
                    }

                }
                Console.WriteLine(player.name + ": " + player.hp + "/" + player.maxhp + " HP, " + player.atk + " ATK, " + player.def + " DEF, Class: " + player.ClassName);
            }
            bool Continue = true;
            while (Continue)
            {
                RenameEnemy(enemy);
                Gameplay();
                string YesNo = "";
                while (YesNo != "y" && YesNo != "n")
                {
                    Console.WriteLine("Continue? [Y/N]");
                    YesNo = Console.ReadLine().ToLower();
                    if (YesNo == "y")
                    {
                        Continue = true;
                        foreach (Player player in FunGang)
                        {
                            player.hp = player.maxhp;
                        }
                    }
                    else if (YesNo == "n")
                    {
                        Continue = false;
                    }
                }
            }
        }
        static void RenameEnemy(Enemy enemy)
        {
            List<string> EnemyNames = new()
                {
                    "Average Person", "Some Enemy", "Sans", "Amogus", "LPSam", "CEO of MegaCorp", "Joe", "Hamburger", "Extraordinary Person"
                };
            Random random = new();
            enemy.name = EnemyNames[random.Next(EnemyNames.Count)];
            switch (enemy.name)
            {
                case ("Average Person"):
                    enemy.hp = 50;
                    enemy.atk = 5;
                    enemy.def = 5;
                    enemy.id = 1;
                    break;
                case ("Some Enemy"):
                    enemy.hp = random.Next(50, 150);
                    enemy.atk = random.Next(5, 15);
                    enemy.def = random.Next(5, 15);
                    enemy.id = 2;
                    break;
                case ("Sans"):
                    enemy.hp = 10;
                    enemy.atk = 1;
                    enemy.def = 50;
                    enemy.id = 3;
                    break;
                case ("Amogus"):
                    enemy.hp = 250;
                    enemy.atk = 25;
                    enemy.def = 5;
                    enemy.id = 4;
                    break;
                case ("LPSam"):
                    enemy.hp = 400;
                    enemy.atk = 7;
                    enemy.def = 13;
                    enemy.id = 5;
                    break;
                case ("CEO of MegaCorp"):
                    enemy.hp = 250;
                    enemy.atk = 15;
                    enemy.def = 5;
                    enemy.id = 6;
                    break;
                case ("Joe"):
                    enemy.hp = 500;
                    enemy.atk = 20;
                    enemy.def = 8;
                    enemy.id = 7;
                    break;
                case ("Hamburger"):
                    enemy.hp = 10;
                    enemy.atk = 20;
                    enemy.def = 40;
                    enemy.id = 8;
                    break;
                case ("Extraordinary Person"):
                    enemy.hp = 75;
                    enemy.atk = 8;
                    enemy.def = 8;
                    enemy.id = 9;
                    break;
                default:
                    enemy.hp = 100;
                    enemy.atk = 10;
                    enemy.def = 10;
                    enemy.id = 0;
                    enemy.name = "Default Enemy that shouldnt appear ever";
                    break;
            }
            enemy.killed = false;
            enemy.spared = false;
            enemy.defeat = false;
    }
        static void PlayerTurnProcessing()
        {
            foreach (Player player in FunGang)
            {
                if (ATPContainer.tp >= 100)
                {
                    ATPContainer.tp = 100;
                }
                if (enemy.SpareReadiness >= 100)
                {
                    enemy.SpareReadiness = 100;
                }
                if (!enemy.defeat)
                {
                    Console.WriteLine(player.name + ": " + player.hp + "/" + player.maxhp + " HP, " + player.atk + " ATK, " + player.def + " DEF, " + ATPContainer.tp + " TP, Class: " + player.ClassName);
                    if (!player.justDowned && !player.down)
                    {
                        doSomething = false;
                        while (!doSomething)
                        {
                            player.PlayerTurn();
                            PlayerActionProcessing(player);
                        }
                    }
                    else if (player.justDowned)
                    {
                        EverybodyDown++;
                        player.justDowned = false;
                        Console.WriteLine(player.name + " was downed");
                    }
                    else if (player.hp > 0 && player.down)
                    {
                        EverybodyDown--;
                        player.down = false;
                        Console.WriteLine(player.name + " is back!");
                    }
                    else if (player.down)
                    {
                        Console.WriteLine(player.name + "is still down");
                    }
                }
            }
        }
        static void PlayerActionProcessing(Player player)
        {
            switch (player.PlayerDoes)
            {
                case ("atk"):
                case ("attack"):
                case ("1"):
                    if (player.canFight)
                    {
                        enemy.Fight(player.atk, player.name);
                        doSomething = true;
                    }
                    else
                    {
                        Console.WriteLine("Cant Fight: Is Pacifist");
                    }
                    break;
                case ("def"):
                case ("defend"):
                case ("2"):
                    Def(player.ClassName == "pacifist", player);
                    doSomething = true;
                    break;
                case ("check"):
                case ("3"):
                    enemy.Check();
                    doSomething = true;
                    break;
                case ("heal"):
                case ("4"):
                    if (player.ClassName == "healer")
                    {
                        Random random = new();
                        int healedPlayerPos = random.Next(FunGang.Count);
                        Player getHealed = FunGang[healedPlayerPos];
                        getHealed.Heal();
                    }
                    player.Heal();
                    doSomething = true;
                    break;
                case ("tpheal"):
                case ("5"):
                    if (ATPContainer.tp >= 30)
                    {
                        if (player.ClassName == "healer")
                        {
                            Random random = new();
                            int healedPlayerPos = random.Next(FunGang.Count);
                            Player getHealed = FunGang[healedPlayerPos];
                            getHealed.Heal();
                        }
                        TPHeal(player);
                        doSomething = true;
                    }
                    else
                    {
                        Console.WriteLine("Not Enougth TP");
                    }
                    break;
                case ("specatk"):
                case ("special attack"):
                case ("6"):
                    if (ATPContainer.tp >= 30 && player.canFight)
                    {
                        ATPContainer.tp = enemy.SpecAtk(ATPContainer.tp, player.atk, player.name);
                        doSomething = true;
                    }
                    else
                    {
                        if (ATPContainer.tp < 30)
                        {
                            Console.WriteLine("Not enougth TP");
                        }
                        if (!player.canFight)
                        {
                            Console.WriteLine("Cant Fight: Is Pacifist");
                        }
                    }
                    break;
                case ("spare"):
                case ("mercy"):
                case ("7"):
                    if (player.canSpare)
                    {
                        enemy.Spare();
                        doSomething = true;
                    }
                    else
                    {
                        Console.WriteLine("Cant Spare: Is Murderer");
                    }
                    break;
                case ("act"):
                case ("8"):
                    enemy.Act(player.name);
                    doSomething = true;
                    break;
                default:
                    Console.WriteLine("Unknown Operation. Try again!");
                    break;
            }
        }
        static void EnemyTurnProcessing()
        {
            if (!enemy.defeat && EverybodyDown != NumberOfPlayers)
            {
                bool SuccessfulAtk = false;
                while (!SuccessfulAtk)
                {
                    Random random = new();
                    int attackedPlayerPos = random.Next(FunGang.Count);
                    Player getAttacked = FunGang[attackedPlayerPos];
                    if (!getAttacked.down)
                    {
                        getAttacked.GetHit(enemy.atk, enemy.name);
                        SuccessfulAtk = true;
                    }
                }
            }
        }
        static void Gameplay()
        {
            RenameEnemy(enemy);
            foreach (Player player in FunGang)
            {
                player.hp = player.maxhp;
                player.down = false;
                player.justDowned = false;
            }
            while(EverybodyDown < NumberOfPlayers && !enemy.defeat)
            {
                PlayerTurnProcessing();
                EnemyTurnProcessing();
            }
            if (EverybodyDown == NumberOfPlayers)
            {
                Console.WriteLine("Game Over: You lost");
                ThingsKilled = 0;
                ThingsSpared = 0;
            }
            else if (enemy.defeat)
            {
                Console.WriteLine("Game Over: You won");
                if (enemy.killed)
                {
                    ThingsKilled++;
                }
                if (enemy.spared)
                {
                    ThingsSpared++;
                }
                Console.WriteLine("Kill Count: " + ThingsKilled + " Spare Count: " + ThingsSpared);
            }
        }

        static void TPHeal(Player player)
        {
            ATPContainer.tp -= 30;
            player.TPHeal();
        }

        static void Def(bool isMercyful, Player player)
        {
            if (isMercyful)
            {
                ATPContainer.tp += 30;
            }
            else
            {
                ATPContainer.tp += 15;
            }
            player.Defend();
        }


    }
    class TPContainer
    {
        public int tp = 0;
    }
    class Enemy
    {
        public bool killed = false;
        public bool spared = false;
        public bool defeat = false;
        public int hp = 100;
        public int atk = 10;
        public int def = 10;
        public int id = 0;
        public string name = "Default Enemy that shouldnt appear ever";
        public int SpareReadiness = 0;
        public void Act(string playername)
        {
            switch (name)
            {
                case ("Average Person"):
                    Console.WriteLine(playername + " told " + name + " to stop fighting. They became more convinced.");
                    SpareReadiness += 25;
                    break;
                case ("Some Enemy"):
                    Console.WriteLine(playername + " did something. It worked... somehow");
                    SpareReadiness += 15;
                    break;
                case ("Sans"):
                    Console.WriteLine(playername + " told " + name + " to stop fighting. He became completly convinced, mostly because hes too lazy to fight.");
                    SpareReadiness += 100;
                    break;
                case ("Amogus"):
                    Console.WriteLine(playername + " recited the 'Stop posting about Among Us' copypasta. They became more convinced that you're a crewmate.");
                    SpareReadiness += 20;
                    break;
                case ("LPSam"):
                    Console.WriteLine(playername + " played Uno with " + name + ". They want to fight less now.");
                    SpareReadiness += 25;
                    break;
                case ("CEO of MegaCorp"):
                    Console.WriteLine(playername + " formed a workers union. " + name + "'s Will to fight rises, but his Defence loosened.");
                    atk += 2;
                    def -= 2;
                    SpareReadiness += 10;
                    break;
                case ("Joe"):
                    Console.WriteLine(playername + " asked who " + name + " is. " + name + " fell over in laughter.");
                    SpareReadiness += 34;
                    atk -= 2;
                    def -= 2;
                    break;
                case ("Hamburger"):
                    Console.WriteLine(playername + " bites into the " + name + ".");
                    hp -= 2;
                    SpareReadiness += 15;
                    break;
                case ("Extraordinary Person"):
                    Console.WriteLine(playername + " told " + name + " to stop fighting. They became slightly more convinced.");
                    SpareReadiness += 5;
                    break;
                default:
                    Console.WriteLine(playername + " started to default dance. This is a safety net for if something goes wrong.");
                    SpareReadiness += 50;
                    break;
            }
        }
        public void Check()
        {
            Console.WriteLine(name + ": " + hp + " HP, " + atk + " ATK, " + def + " DEF, " + SpareReadiness + "% ready to be spared.");
        }
        public void Spare()
        {
            Console.WriteLine(name + " was spared");
            if (SpareReadiness == 100 || name == "Sans")
            {
                defeat = true;
                spared = true;
            } else
            {
                Console.WriteLine("...but they werent convinced yet");
            }
        }
        public int SpecAtk(int TP, int playeratk, string playername)
        {
            Random random = new();
            TP -= 30;
            int dmg;
            if (def < 1)
            {
                dmg = 5 * playeratk;
            } else
            {
                dmg = 5 * playeratk / (def / random.Next(1, def + 1));
            }
            hp -= dmg;
            Console.WriteLine(playername + " dealt " + dmg + " Damage");
            if (hp <= 0)
            {
                defeat = true;
                killed = true;
                Console.WriteLine(name + " was defeated!");
            }
            return TP;
        }
        public void Fight(int playeratk, string playername)
        {
            Random random = new();
            int dmg;
            if (def < 1)
            {
                dmg = playeratk;
            }
            else
            {
                dmg = playeratk / (def / random.Next(1, def + 1));
            }
            hp -= dmg;
            Console.WriteLine(playername + " dealt " + dmg + " Damage");
            if (hp <= 0)
            {
                defeat = true;
                Console.WriteLine(name + " was defeated!");
                killed = true;
            }
        }
    }
    class Player
    {
        public int maxhp;
        public int hp;
        public int atk;
        public int def;
        public string name;
        public int playerID;
        public string ClassName;
        public bool down = false;
        public bool justDowned = false;
        public bool isDefending = false;
        public bool canSpare = true;
        public bool canFight = true;
        public string PlayerDoes;
        public void Heal()
        {
            hp += 15;
            if (hp >= maxhp)
            {
                hp = maxhp;
                Console.WriteLine(name + " was healed. HP fully restored!");
            }
            else
            {
                Console.WriteLine(name + " was healed. 15 HP Restored!");
            }
        }
        public void TPHeal()
        {
            hp += 50;
            if (hp == maxhp)
            {
                Console.WriteLine(name + " healed themselves alot. HP fully restored!");
            }
            else if (hp > maxhp)
            {
                Console.WriteLine(name + " healed themselves alot. They are now overhealed!");
            }
            else
            {
                Console.WriteLine(name + " healed themselves alot. 50 HP restored!");
            }
        }
        public void Defend()
        {
            isDefending = true;
        }
        public void PlayerTurn()
        {
            Console.WriteLine("What will " + name + " do?: [atk/def/check/heal/tpheal/specatk/spare/act]");
            PlayerDoes = Console.ReadLine().ToLower();
        }
        public void GetHit(int Enemyatk, string Enemyname)
        {
            int dmg;
            if (isDefending)
            {
                dmg = 5 + ((Enemyatk / 2) / def);
                isDefending = false;
            }
            else
            {
                dmg = 5 + (Enemyatk / def);
            }
            hp -= dmg;
            Console.WriteLine(Enemyname + " dealt " + dmg + " Damage to " + name);
            if (hp <= 0)
            {
                down = true;
                justDowned = true;
            }
        }
    }
}
