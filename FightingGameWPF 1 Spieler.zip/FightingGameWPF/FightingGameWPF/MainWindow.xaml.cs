﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FightingGameWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool ActMenuOpen = false;
        bool EnemySpared = false;
        bool EnemyKilled = false;
        bool PlayerKilled = false;
        int Spared = 0;
        int Killed = 0;
        Enemy WPF = new Enemy();
        Player User = new Player();
        SoundPlayer MainTheme = new SoundPlayer();
        public MainWindow()
        {
            InitializeComponent();
        }
        void GameStart(object sender, RoutedEventArgs e)
        {
            if (PlayerKilled)
            {
                Spared = 0;
                Killed = 0;
            } else if (EnemyKilled) 
            {
                Killed++;
            } else if (EnemySpared)
            {
                Spared++;
            }
            Random rng = new Random();
            if(Spared != 0)
            {
                WPF.hp = rng.Next(50, 150) + (5 * Killed / Spared);
                WPF.atk = rng.Next(10, 20) + (5 * Killed / Spared);
                WPF.def = rng.Next(10, 20) + (5 * Killed / Spared);
            } else
            {
                WPF.hp = rng.Next(50, 150) + (5 * Killed);
                WPF.atk = rng.Next(10, 20) + (5 * Killed);
                WPF.def = rng.Next(10, 20) + (5 * Killed);
            }
            WPF.SpareReadiness = 0;
            User.hp = 100 + (5 * Killed);
            User.maxhp = User.hp;
            User.tp = 0;
            User.atk = 10 + (5 * Killed);
            User.def = 10 + (5 * Spared);
            ShowsATK.Content = User.atk + " ATK";
            ShowsDEF.Content = User.def + " DEF";
            User.Name = EnterYourNameHere.Text;
            NameContainer.Content = User.Name;
            CoverUp.Visibility = Visibility.Hidden;
            EnterYourNameHere.Visibility = Visibility.Hidden;
            Confirmation.Visibility = Visibility.Hidden;
            GameOver.Visibility = Visibility.Hidden;
            PlayerKilled = false;
            EnemyKilled = false;
            EnemySpared = false;
            GainedTP.Width = 0;
            GainedTPLabel.Content = "0% TP";
            LostHP.Width = 0;
            WPF.exp = WPF.hp;
            MainTheme.SoundLocation = @"\FightingGameWPF\FightingGameWPF\battletheme.wav";
            MainTheme.PlayLooping();
        }
        void Action(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(User.Name + " patched some bugs... +20% more ready to spare");
            WPF.SpareReadiness = WPF.SpareReadiness + 20;
            EnemyAttacks();
        }
        void Heal(object sender, RoutedEventArgs e)
        {
            User.hp = User.hp + 15;
            if (User.hp >= User.maxhp)
            {
                User.hp = User.maxhp;
                LostHP.Width = 0;
                MessageBox.Show(User.Name + " healed themselves to full health");
            }
            else
            {
                LostHP.Width = 300 / User.maxhp * (User.maxhp - User.hp);
                MessageBox.Show(User.Name + " healed themselves 15 HP");
            }
            EnemyAttacks();
        }
        void ActMenu(object sender, RoutedEventArgs e)
        {
            if (!ActMenuOpen && !EnemyKilled && !EnemySpared && !PlayerKilled)
            {
                ActMenuOpen = true;
                check.Visibility = Visibility.Visible;
                specatk.Visibility = Visibility.Visible;
                tpheal.Visibility = Visibility.Visible;
                act.Visibility = Visibility.Visible;
            } else if (ActMenuOpen && !EnemyKilled && !EnemySpared && !PlayerKilled)
            {
                ActMenuOpen = false;
                check.Visibility = Visibility.Hidden;
                specatk.Visibility = Visibility.Hidden;
                tpheal.Visibility = Visibility.Hidden;
                act.Visibility = Visibility.Hidden;
            } else
            {
                ActMenuOpen = false;
                check.Visibility = Visibility.Hidden;
                specatk.Visibility = Visibility.Hidden;
                tpheal.Visibility = Visibility.Hidden;
                act.Visibility = Visibility.Hidden;
            }
        }
        void mercy(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("You showed Mercy to the enemy");
            if (WPF.SpareReadiness == 100)
            {
                MainTheme.Stop();
                EnemySpared = true;
                MessageBox.Show("---------> YOU WON <---------" + Environment.NewLine + "You gained 0 EXP and " + (10 + (User.tp * 2)) + " G!");
                CoverUp.Visibility = Visibility.Visible;
                EnterYourNameHere.Visibility = Visibility.Visible;
                Confirmation.Visibility = Visibility.Visible;
                GameOver.Visibility = Visibility.Visible;
                GameOver.Content = "Vs. WPF Fight";
                Confirmation.Content = "Play again";
            }
            else
            {
                MessageBox.Show("...but they werent ready to be spared");
                WPF.SpareReadiness = WPF.SpareReadiness + 5;
                EnemyAttacks();
            }
        }
        void specialatk(object sender, RoutedEventArgs e)
        {
            if (ActMenuOpen && !EnemyKilled && !EnemySpared && !PlayerKilled && User.tp >= 50)
            {
                ActMenuOpen = false;
                check.Visibility = Visibility.Hidden;
                specatk.Visibility = Visibility.Hidden;
                tpheal.Visibility = Visibility.Hidden;
                act.Visibility = Visibility.Hidden;
                User.tp = User.tp - 50;
                GainedTP.Width = User.tp * 3;
                GainedTPLabel.Content = User.tp + "% TP";
                WPF.hp = WPF.hp - (50 + (User.atk / WPF.def));
                MessageBox.Show(User.Name + " dealt " + (50 + (User.atk / WPF.def)) + " Damage");
                if (WPF.hp <= 0)
                {
                    MainTheme.Stop();
                    WPF.hp = 0;
                    EnemyKilled = true;
                    MessageBox.Show("---------> YOU WON <---------" + Environment.NewLine + "You gained " + WPF.exp + " EXP and " + (10 + (User.tp * 2)) + " G!");
                    CoverUp.Visibility = Visibility.Visible;
                    EnterYourNameHere.Visibility = Visibility.Visible;
                    Confirmation.Visibility = Visibility.Visible;
                    GameOver.Visibility = Visibility.Visible;
                    GameOver.Content = "Vs. WPF Fight";
                    Confirmation.Content = "Play again";
                } else
                {
                    EnemyAttacks();
                }
            }
        }
        void EnemyAttacks()
        {
            ActMenuOpen = false;
            check.Visibility = Visibility.Hidden;
            specatk.Visibility = Visibility.Hidden;
            tpheal.Visibility = Visibility.Hidden;
            act.Visibility = Visibility.Hidden;
            if (WPF.SpareReadiness > 100)
            {
                WPF.SpareReadiness = 100;
            }
            if (WPF.hp <= 20)
            {
                WPF.SpareReadiness = 100;
            }
            Random rng = new Random();
            int standardmg = rng.Next(1, 10);
            int dmgdealt = standardmg + WPF.atk / (User.def + User.adddef);
            User.hp = User.hp - dmgdealt;
            LostHP.Width = 300 / User.maxhp * (User.maxhp - User.hp);
            MessageBox.Show("The enemy did " + dmgdealt + " Damage");
            User.adddef = 0;
            if (User.hp <= 0)
            {
                MainTheme.Stop();
                User.hp = 0;
                LostHP.Width = 300;
                PlayerKilled = true;
                MainTheme.SoundLocation = @"\FightingGameWPF\FightingGameWPF\GameOver.wav";
                MainTheme.Play();
                CoverUp.Visibility = Visibility.Visible;
                EnterYourNameHere.Visibility = Visibility.Visible;
                Confirmation.Visibility = Visibility.Visible;
                GameOver.Visibility = Visibility.Visible;
                GameOver.Content = "Game Over";
                Confirmation.Content = "Try again";
            }
        }
        void EnemyCheck(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enemy: " + WPF.hp + " HP " + WPF.atk + " ATK " + WPF.def + " DEF " + WPF.SpareReadiness + "% ready to be spared");
            EnemyAttacks();
        }
        void attack(object sender, RoutedEventArgs e)
        {
            if (!EnemyKilled && !EnemySpared && !PlayerKilled)
            {
                Random rng = new Random();
                int standardmg = rng.Next(1, 10);
                if(WPF.SpareReadiness == 100)
                {
                    WPF.hp = WPF.hp - (standardmg * 4 + (User.atk / WPF.def));
                    MessageBox.Show(User.Name + " dealt " + (standardmg * 4 + (User.atk / WPF.def)) + " Damage");
                    WPF.SpareReadiness = 50;
                } else
                {
                    WPF.hp = WPF.hp - (standardmg + (User.atk / WPF.def));
                    MessageBox.Show(User.Name + " dealt " + (standardmg + (User.atk / WPF.def)) + " Damage");
                }
                if (WPF.hp <= 0)
                {
                    MainTheme.Stop();
                    WPF.hp = 0;
                    EnemyKilled = true;
                    MessageBox.Show("---------> YOU WON <---------" + Environment.NewLine + "You gained " + WPF.exp + " EXP and " + (10 + (User.tp * 2)) + " G!");
                    CoverUp.Visibility = Visibility.Visible;
                    EnterYourNameHere.Visibility = Visibility.Visible;
                    Confirmation.Visibility = Visibility.Visible;
                    GameOver.Visibility = Visibility.Visible;
                    GameOver.Content = "Vs. WPF Fight";
                    Confirmation.Content = "Play again";
                }
                else
                {
                    EnemyAttacks();
                }
            }
        }
        void tpHeal(object sender, RoutedEventArgs e)
        {
            if(User.tp >= 30)
            {
                User.hp = User.hp + 50;
                if(User.hp >= User.maxhp)
                {
                    User.hp = User.maxhp;
                    LostHP.Width = 0;
                    User.tp = User.tp - 30;
                    GainedTP.Width = User.tp * 3;
                    GainedTPLabel.Content = User.tp + "% TP";
                    MessageBox.Show(User.Name + " was healed fully");
                }
                else
                {
                    LostHP.Width = 300 / User.maxhp * (User.maxhp - User.hp);
                    User.tp = User.tp - 30;
                    GainedTP.Width = User.tp * 3;
                    GainedTPLabel.Content = User.tp + "% TP";
                    MessageBox.Show(User.Name + " was healed by 50 hp");
                }
                EnemyAttacks();
            }
        }
        void Defend(object sender, RoutedEventArgs e)
        {
            if(!EnemyKilled && !EnemySpared && !PlayerKilled)
            {
                User.adddef = 5;
                User.tp = User.tp + 15;
                if (User.tp > 100)
                {
                    User.tp = 100;
                }
                GainedTP.Width = User.tp * 3;
                GainedTPLabel.Content = User.tp + "% TP";
                EnemyAttacks();
            }
        }
    }
    class Player
    {
        public int adddef = 0;
        public string Name = "";
        public int hp = 100;
        public int maxhp;
        public int atk = 10;
        public int def = 10;
        public int tp = 0;
    }
    class Enemy
    {
        static Random rng = new Random();
        public int hp = rng.Next(50, 100);
        public int exp = 0;
        public int atk = rng.Next(10, 20);
        public int def = rng.Next(5, 15);
        public int SpareReadiness = 0;
    }
}
