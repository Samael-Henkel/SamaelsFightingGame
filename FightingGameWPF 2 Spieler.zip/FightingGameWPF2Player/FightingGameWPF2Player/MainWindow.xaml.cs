﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FightingGameWPF2Player
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        player Player1 = new player();
        player Player2 = new player();
        int playerTurn = 1;
        SoundPlayer soundPlayer = new SoundPlayer();
        void defend(object sender, RoutedEventArgs e)
        {
            if (playerTurn == 1)
            {
                Player1.defend();
                playerTurn = 2;
            }
            else
            {
                Player2.defend();
                playerTurn = 1;
            }
            checkAfterTurn();
        }
        void heal(object sender, RoutedEventArgs e)
        {
            if (playerTurn == 1)
            {
                Player1.heal();
                playerTurn = 2;
            }
            else
            {
                Player2.heal();
                playerTurn = 1;
            }
            checkAfterTurn();
        }
        void surrender(object sender, RoutedEventArgs e)
        {
            if (playerTurn == 1)
            {
                Player1.Surrender();
                playerTurn = 2;
            }
            else
            {
                Player2.Surrender();
                playerTurn = 1;
            }
            checkAfterTurn();
        }
        void fight(object sender, RoutedEventArgs e)
        {
            if (playerTurn == 1)
            {
                Player2.attack();
                playerTurn = 2;
            }
            else
            {
                Player1.attack();
                playerTurn = 1;
            }
            checkAfterTurn();
        }
        void special(object sender, RoutedEventArgs e)
        {
            if (playerTurn == 1)
            {
                Player2.special();
                playerTurn = 2;
            }
            else
            {
                Player1.special();
                playerTurn = 1;
            }
            checkAfterTurn();
        }
        void checkAfterTurn()
        {
            if (Player1.hp <= 0)
            {
                Player1.hp = 0;
                Player1.dead = true;
            }
            else if (Player1.hp > 100)
            {
                Player1.hp = 100;
            }
            if (Player2.hp <= 0)
            {
                Player2.hp = 0;
                Player2.dead = true;
            }
            else if (Player2.hp > 100)
            {
                Player2.hp = 100;
            }
            TPPlayer1.Width = Player1.tp * 4;
            HPPlayer1.Width = Player1.hp * 4;
            HPCount1.Content = Player1.hp + "/" + Player1.maxhp + " HP";
            TPCount1.Content = Player1.tp + "% TP";
            TPPlayer2.Width = Player2.tp * 4;
            HPPlayer2.Width = Player2.hp * 4;
            HPCount2.Content = Player2.hp + "/" + Player2.maxhp + " HP";
            TPCount2.Content = Player2.tp + "% TP";
            if (Player1.surrender == false && Player1.dead == false && Player2.surrender == false && Player2.dead == false)
            {
                if (playerTurn == 1)
                {
                    P2Defend.Visibility = Visibility.Hidden;
                    P2Fight.Visibility = Visibility.Hidden;
                    P2Heal.Visibility = Visibility.Hidden;
                    P2Special.Visibility = Visibility.Hidden;
                    P2Surrender.Visibility = Visibility.Hidden;
                    P1Defend.Visibility = Visibility.Visible;
                    P1Fight.Visibility = Visibility.Visible;
                    P1Heal.Visibility = Visibility.Visible;
                    P1Special.Visibility = Visibility.Visible;
                    P1Surrender.Visibility = Visibility.Visible;
                    
                }
                else if (playerTurn == 2)
                {
                    P1Defend.Visibility = Visibility.Hidden;
                    P1Fight.Visibility = Visibility.Hidden;
                    P1Heal.Visibility = Visibility.Hidden;
                    P1Special.Visibility = Visibility.Hidden;
                    P1Surrender.Visibility = Visibility.Hidden;
                    P2Defend.Visibility = Visibility.Visible;
                    P2Fight.Visibility = Visibility.Visible;
                    P2Heal.Visibility = Visibility.Visible;
                    P2Special.Visibility = Visibility.Visible;
                    P2Surrender.Visibility = Visibility.Visible;
                    
                }
            } else
            {
                soundPlayer.Stop();
                P1Defend.Visibility = Visibility.Hidden;
                P1Fight.Visibility = Visibility.Hidden;
                P1Heal.Visibility = Visibility.Hidden;
                P1Special.Visibility = Visibility.Hidden;
                P1Surrender.Visibility = Visibility.Hidden;
                P2Defend.Visibility = Visibility.Hidden;
                P2Fight.Visibility = Visibility.Hidden;
                P2Heal.Visibility = Visibility.Hidden;
                P2Special.Visibility = Visibility.Hidden;
                P2Surrender.Visibility = Visibility.Hidden;
                if(Player1.surrender || Player1.dead)
                {
                    MessageBox.Show(NameOfPlayer2.Content + " won");
                    EnterP1Name.Visibility = Visibility.Visible;
                    EnterP2Name.Visibility = Visibility.Visible;
                    StartButton.Visibility = Visibility.Visible;
                    Background.Visibility = Visibility.Visible;
                    Title.Visibility = Visibility.Visible;
                } else if (Player2.surrender || Player2.dead)
                {
                    MessageBox.Show(NameOfPlayer1.Content + " won");
                    EnterP1Name.Visibility = Visibility.Visible;
                    EnterP2Name.Visibility = Visibility.Visible;
                    StartButton.Visibility = Visibility.Visible;
                    Background.Visibility = Visibility.Visible;
                    Title.Visibility = Visibility.Visible;
                }
            }
        }
        void Start(object sender, RoutedEventArgs e)
        {
            NameOfPlayer1.Content = EnterP1Name.Text;
            NameOfPlayer2.Content = EnterP2Name.Text;
            EnterP1Name.Visibility = Visibility.Hidden;
            EnterP2Name.Visibility = Visibility.Hidden;
            StartButton.Visibility = Visibility.Hidden;
            Background.Visibility = Visibility.Hidden;
            Title.Visibility = Visibility.Hidden;
            Player1.hp = Player1.maxhp;
            Player2.hp = Player2.maxhp;
            Player1.tp = 0;
            Player2.tp = 0;
            Player1.surrender = false;
            Player1.dead = false;
            Player2.surrender = false;
            Player2.dead = false;
            playerTurn = 1;
            if (NameOfPlayer2.Content.ToString() == "Amogus" || NameOfPlayer2.Content.ToString() == "Among Us" || NameOfPlayer2.Content.ToString() == "sus")
            {
                Player2Sprite.Source = new BitmapImage(new Uri(@"/Getoutofmypng.png", UriKind.Relative));
                soundPlayer.SoundLocation = @"/FightingGameWPF2Player/FightingGameWPF2Player/ohno.mp5.wav";
                soundPlayer.PlayLooping();
            }
            else
            {
                Player2Sprite.Source = new BitmapImage(new Uri(@"/playersprite2.png", UriKind.Relative));
                soundPlayer.SoundLocation = @"/FightingGameWPF2Player/FightingGameWPF2Player/maintheme.wav";
                soundPlayer.PlayLooping();
            }
            checkAfterTurn();
        }
        public MainWindow()
        {
            InitializeComponent();
        }
        class player
        {
            public bool surrender = false;
            public bool dead = false;
            public string Name = "";
            public int maxhp = 100;
            public int hp = 100;
            public int tp = 0;
            public int atk = 10;
            public int def = 10;
            public bool Defending = false;
            Random rng = new Random();
            public void defend()
            {
                Defending = true;
                tp = tp + 25;
                if(tp > 100)
                {
                    tp = 100;
                }
            }
            public void heal()
            {
                hp = hp + 5 + tp;
                tp = 0;
            }
            public void attack()
            {
                if (Defending == false)
                {
                    hp = hp - (rng.Next(1, atk) / rng.Next(1, def));
                }
                else
                {
                    hp = hp - (rng.Next(1, atk) / rng.Next(3, def + 3));
                    Defending = false;
                }
                if (hp <= 0)
                {
                    hp = 0;
                }
            }
            public void special()
            {
                if (Defending == false)
                {
                    hp = hp - (rng.Next(1, atk * 5) / rng.Next(1, def));
                }
                else
                {
                    hp = hp - (rng.Next(1, atk * 5) / rng.Next(5, def + 10));
                    Defending = false;
                }
                if (hp <= 0)
                {
                    hp = 0;
                }
            }
            public void Surrender()
            {
                surrender = true;
            }
        }
    }
}
