using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FightingGameV5.ButtonFunctionality
{
    // Made on 04.10.2022
    public class ButtonFunctionalityClass
    {
        Random random = new();
        public int Fight(int PlayerAtk, int EnemyDef, int EnemyHP)
        {
            int dmg = random.Next(1, PlayerAtk + 5 - EnemyDef);
            EnemyHP -= dmg;
            MessageBox.Show("You've dealt " + dmg + " HP Damage", "Fight");
            return EnemyHP;
        }
        public int defendTP(int TP, int def)
        {
            TP += 3 * def;
            if(TP > 100)
            {
                TP = 100;
            }
            return TP;
        }
        public bool defendDEF(bool isDef)
        {
            isDef = true;
            return isDef;
        }
    }
}