﻿using FightingGameV5.ButtonFunctionality;
using FightingGameV5.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FightingGameV5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            GameLogic(); //added 03.10.2022
        }
        //Did this on 30.09.2022
        public void Movement(object sender, RoutedEventArgs e)
        {
            /* double leftMargin = Soul.Margin.Left;
               double topMargin = Soul.Margin.Top;
               double rightMargin = Soul.Margin.Right;
               double bottomMargin = Soul.Margin.Bottom;
               Button clickedButton = sender as Button;
               string direction = Convert.ToString(clickedButton.Content);
               if (direction == "↑")
               {
                   topMargin -= 1;
                   bottomMargin += 1;
               }
               else if (direction == "↓")
               {
                   topMargin += 1;
                   bottomMargin -= 1;
               }
               else if (direction == "→")
               {
                   leftMargin += 1;
                   rightMargin -= 1;
               }
               else if (direction == "←")
               {
                   leftMargin -= 1;
                   rightMargin += 1;
               }
               Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
               Unnessesary due to Keyboard Controls working */
        }
        public void KeyboardMovement(Key e)
        {
            double leftMargin = Soul.Margin.Left;
            double topMargin = Soul.Margin.Top;
            double rightMargin = Soul.Margin.Right;
            double bottomMargin = Soul.Margin.Bottom;
            if (e == Key.W)
            {
                topMargin -= 2;
                bottomMargin += 2;
                if (topMargin < 10)
                {
                    topMargin = 10;
                    bottomMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                }
            }
            else if (e == Key.S)
            {
                topMargin += 2;
                bottomMargin -= 2;
                if (bottomMargin < 10)
                {
                    bottomMargin = 10;
                    topMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                }
            }
            if (e == Key.A)
            {
                leftMargin -= 2;
                rightMargin += 2;
                if (leftMargin < 10)
                {
                    leftMargin = 10;
                    rightMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                }
            }
            else if (e == Key.D)
            {
                leftMargin += 2;
                rightMargin -= 2;
                if (rightMargin < 10)
                {
                    rightMargin = 10;
                    leftMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                }
            }
            Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
        }
        // 03.10.2022
        public BitmapImage RedMode = new(new Uri("RedHeart.png", UriKind.Relative));
        public BitmapImage BlueMode = new(new Uri("BlueHeart.png", UriKind.Relative));
        public void GameControl(object Object, EventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.W) || Keyboard.IsKeyDown(Key.Up))
            {
                KeyboardMovement(Key.W);
            } else if (Soul.Source == BlueMode)
            {
                KeyboardMovement(Key.S);
            }
            if (Keyboard.IsKeyDown(Key.A) || Keyboard.IsKeyDown(Key.Left))
            {
                KeyboardMovement(Key.A);
            }
            if (Keyboard.IsKeyDown(Key.S) || Keyboard.IsKeyDown(Key.Down))
            {
                KeyboardMovement(Key.S);
            }
            if (Keyboard.IsKeyDown(Key.D) || Keyboard.IsKeyDown(Key.Right))
            {
                KeyboardMovement(Key.D);
            }
            obstaclePositionUpdate();
        }
        class Obstacle
        {
            static Random random = new();
            public int height = random.Next(20, 150);
            public int width = 10;
            static string[] PossiblePositions = new string[]
            {
                "Top", "Bottom",
            };
            public string position = PossiblePositions[random.Next(0, PossiblePositions.Length)];
            public bool right = random.Next(0, 100) >= 50;
            public double speed; // Different Speeds for each obstacle: Added 05.10.2022 
        }
        DispatcherTimer TimeControl = new();
        int TimeSurvived = 0;
        bool Gamestart = true;
        Obstacle[] obstacle = { new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle(), new Obstacle()}; /// Support for multiple obstacles: Added 04.10.2022
        public void GameLogic()
        {
            int i = 0;
            int j = 0;
            TimeSurvived = 0;
            Random random = new();
            int FiftyFifty = random.Next(0, 100);
            if(FiftyFifty >= 50)            // Random Chance to be blue: Added 04.10.2022
            {
                Soul.Source = BlueMode;
                Soul.Visibility = Visibility.Visible;
            } else
            {
                Soul.Source = RedMode;
                Soul.Visibility = Visibility.Visible;
            }
            foreach (Rectangle rectangle in AttackContainer.Children)
            {
                obstacle[i].speed = 1;
                rectangle.Visibility = Visibility.Visible;
                i++;
            }
            if (Gamestart)
            {
                TimeControl.Tick += new EventHandler(GameControl);
                TimeControl.Interval = new TimeSpan(25000); //Game now doesnt speed up every turn: Fixed 05.10.2022
                Gamestart = false;
                foreach (Button button in ItemGrid.Children) //Adding Items: Added 05.10.2022
                {
                    Item item = new Item();
                    item.generateNewItem();
                    button.Content = "* " + item.getName();
                    j++;
                }
            }
            PlayerTurnText.Visibility = Visibility.Hidden;
            TimeControl.Start();
        }
        public void obstaclePositionUpdate()
        {
            int i = 0;
            foreach(Rectangle rectangle in AttackContainer.Children)
            {
                double leftMargin = rectangle.Margin.Left;
                double topMargin = rectangle.Margin.Top;
                double rightMargin = rectangle.Margin.Right;
                double bottomMargin = rectangle.Margin.Bottom;
                if (player.hp > 0 && !GameEnd)
                {
                    if (rightMargin >= Soul.Margin.Right && leftMargin >= Soul.Margin.Left && topMargin <= FightBox.ActualHeight - Soul.Margin.Bottom && obstacle[i].position == "Bottom") // Collision Detection: Added 04.10.2022
                    {
                        if(player.BlockableAtks > 0)
                        {
                            player.BlockableAtks--;
                        } else
                        {
                            player.hp--;
                            if (player.hp < 0)
                            {
                                player.hp = 0;
                            }
                            HPBar.Width = 2 * player.hp;
                            HPContent.Content = Convert.ToString(player.hp) + "/50 HP";
                        }
                    }
                    else if (rightMargin >= Soul.Margin.Right && leftMargin >= Soul.Margin.Left && bottomMargin <= FightBox.ActualHeight - Soul.Margin.Top && obstacle[i].position == "Top")
                    {
                        if (player.BlockableAtks > 0)
                        {
                            player.BlockableAtks--;
                        }
                        else {
                            player.hp--;
                            if (player.hp < 0)
                            {
                                player.hp = 0;
                            }
                            HPBar.Width = 2 * player.hp;
                            HPContent.Content = Convert.ToString(player.hp) + "/50 HP";
                        }
                    }
                    if (obstacle[i].position == "Bottom")
                    {
                        bottomMargin = 10;
                        topMargin = FightBox.ActualHeight - 10 - rectangle.ActualHeight;
                    }
                    else if (obstacle[i].position == "Top")
                    {
                        topMargin = 10;
                        bottomMargin = FightBox.ActualHeight - 10 - rectangle.ActualHeight;
                    }
                    if (obstacle[i].right)
                    {
                        if (rightMargin <= 10)
                        {
                            leftMargin -= obstacle[i].speed;
                            rightMargin += obstacle[i].speed;
                            obstacle[i] = new Obstacle();
                            obstacle[i].right = false;
                            obstacle[i].speed = 1;
                            rectangle.Width = obstacle[i].width;
                            rectangle.MinWidth = obstacle[i].width;
                            rectangle.MaxWidth = obstacle[i].width;
                            rectangle.Height = obstacle[i].height;
                            rectangle.MinHeight = obstacle[i].height;
                            rectangle.MaxHeight = obstacle[i].height;
                        }
                        else
                        {
                            leftMargin += obstacle[i].speed;
                            rightMargin -= obstacle[i].speed;
                        }
                    }
                    else
                    {
                        if (leftMargin <= 10)
                        {
                            leftMargin += obstacle[i].speed;
                            rightMargin -= obstacle[i].speed;
                            obstacle[i] = new Obstacle();
                            obstacle[i].right = true;
                            obstacle[i].speed = 1;
                            rectangle.Width = obstacle[i].width;
                            rectangle.MinWidth = obstacle[i].width;
                            rectangle.MaxWidth = obstacle[i].width;
                            rectangle.Height = obstacle[i].height;
                            rectangle.MinHeight = obstacle[i].height;
                            rectangle.MaxHeight = obstacle[i].height;
                        }
                        else
                        {
                            leftMargin -= obstacle[i].speed;
                            rightMargin += obstacle[i].speed;
                        }
                    }
                } else if(player.hp <= 0 && !GameEnd) //End of Game added 04.10.2022
                {
                    TimeControl.Stop();
                    Soul.Source = new BitmapImage(new Uri("RedHeartShattered.png", UriKind.Relative));
                    GameEnd = true;
                    MessageBox.Show("Gane Over", "You died");
                }
                rectangle.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
                i++;
            }
            if (!GameEnd)
            {
                TimeSurvived += 25000;
            }
            if (TimeSurvived >= 100000000)
            {
                TimeControl.Stop();
                foreach (Rectangle rectangle in AttackContainer.Children)
                {
                    rectangle.Visibility = Visibility.Hidden;
                }
                Soul.Visibility = Visibility.Hidden;
                PlayerTurnText.Visibility = Visibility.Visible;
                PlayerTurn = true;
            }
        }
        //04.10.2022
        class Player
        {
            public int hp = 50;
            public int atk = 20;
            public int def = 20;
            public string Name = "CHARA";
            public bool isDef = false; //Is Defending and blocking Attacks: Added 05.10.2022
            public int BlockableAtks = 0;
            public int TP = 0; //Tension Points: Added 05.10.2022
        }
        class Enemy
        {
            public int hp = 200;
            public int atk = 10;
            public int def = 10;
        }
        Player player = new();
        Enemy enemy = new();
        bool PlayerTurn = false;
        ButtonFunctionalityClass buttonFunctionality = new();
        bool GameEnd = false;
        public void FightButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd && !itemTabOpen)
            {
                buttonFunctionality.Fight(player.atk, enemy.def, enemy.hp);
                if (enemy.hp <= 0)
                {
                    MessageBox.Show("YOU WON: You gained 32 EXP and 76 G", "YOU WON BY FIGHTING");
                }
                else
                {
                    PlayerTurn = false;
                    GameLogic();
                }
            }
        }
        //05.10.2022
        public Item items = new Item();
        public void DefendButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd)
            {
                player.TP = buttonFunctionality.defendTP(player.TP, player.def);
                TPBar.Height = player.TP * 2;
                TPContent.Content = Convert.ToString(player.TP) + "% TP";
                player.isDef = true;
                player.BlockableAtks = 25;
                PlayerTurn = false;
                GameLogic();
            }
        }
        bool itemTabOpen = false;
        public void ItemButton(object sender, RoutedEventArgs e)
        {
            if (PlayerTurn && !GameEnd)
            {
                if (!itemTabOpen)
                {
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    foreach (Button button in ItemGrid.Children)
                    {
                        if (button.Visibility != Visibility.Collapsed)
                        {
                            button.Visibility = Visibility.Visible;
                        }
                    }
                    itemTabOpen = true;
                } else if(itemTabOpen)
                {
                    PlayerTurnText.Visibility = Visibility.Visible;
                    foreach (Button button in ItemGrid.Children)
                    {
                        if (button.Visibility != Visibility.Collapsed)
                        {
                            button.Visibility = Visibility.Hidden;
                        }
                    }
                    itemTabOpen = false;
                } else
                {
                    PlayerTurnText.Visibility = Visibility.Hidden;
                    foreach (Button button in ItemGrid.Children)
                    {
                        if(button.Visibility != Visibility.Collapsed)
                        {
                            button.Visibility = Visibility.Visible;
                        }
                    }
                    itemTabOpen = true;
                }
            }
        }
        public void healing(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string HealingItem = Convert.ToString(button.Content);
            HealingItem = HealingItem.Substring(2);
            player.hp += items.getHeal(HealingItem);
            if (player.hp > 50)
            {
                player.hp = 50;
            }
            HPBar.Width = player.hp * 2;
            HPContent.Content = Convert.ToString(player.hp) + "/50 HP";
            button.Visibility = Visibility.Collapsed;
            foreach (Button button1 in ItemGrid.Children)
            {
                if (button1.Visibility != Visibility.Collapsed)
                {
                    button1.Visibility = Visibility.Hidden;
                }
            }
            PlayerTurn = false;
            GameLogic();
        }
    }
}
