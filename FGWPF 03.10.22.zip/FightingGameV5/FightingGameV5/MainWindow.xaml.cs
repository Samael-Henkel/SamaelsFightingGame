﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FightingGameV5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            GameLogic(); //added 03.10.2022
        }
        //Did this on 30.09.2022
        public void Movement(object sender, RoutedEventArgs e)
        {
            /* double leftMargin = Soul.Margin.Left;
               double topMargin = Soul.Margin.Top;
               double rightMargin = Soul.Margin.Right;
               double bottomMargin = Soul.Margin.Bottom;
               Button clickedButton = sender as Button;
               string direction = Convert.ToString(clickedButton.Content);
               if (direction == "↑")
               {
                   topMargin -= 1;
                   bottomMargin += 1;
               }
               else if (direction == "↓")
               {
                   topMargin += 1;
                   bottomMargin -= 1;
               }
               else if (direction == "→")
               {
                   leftMargin += 1;
                   rightMargin -= 1;
               }
               else if (direction == "←")
               {
                   leftMargin -= 1;
                   rightMargin += 1;
               }
               Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
               Unnessesary due to Keyboard Controls working */
        }
        public void KeyboardMovement(Key e)
        {
            double leftMargin = Soul.Margin.Left;
            double topMargin = Soul.Margin.Top;
            double rightMargin = Soul.Margin.Right;
            double bottomMargin = Soul.Margin.Bottom;
            if (e == Key.W)
            {
                topMargin -= 5;
                bottomMargin += 5;
                if (topMargin < 10)
                {
                    topMargin = 10;
                    bottomMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                }
            }
            else if (e == Key.S)
            {
                topMargin += 5;
                bottomMargin -= 5;
                if (bottomMargin < 10)
                {
                    bottomMargin = 10;
                    topMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                }
            }
            if (e == Key.A)
            {
                leftMargin -= 5;
                rightMargin += 5;
                if (leftMargin < 10)
                {
                    leftMargin = 10;
                    rightMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                }
            }
            else if (e == Key.D)
            {
                leftMargin += 5;
                rightMargin -= 5;
                if (rightMargin < 10)
                {
                    rightMargin = 10;
                    leftMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                }
            }
            Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
        }
        // 03.10.2022
        public BitmapImage RedMode = new(new Uri("RedHeart.png", UriKind.Relative));
        public BitmapImage BlueMode = new(new Uri("BlueHeart.png", UriKind.Relative));
        public void GameControl(object Object, EventArgs e)
        {
            if (Keyboard.IsKeyDown(Key.W) || Keyboard.IsKeyDown(Key.Up))
            {
                KeyboardMovement(Key.W);
            } else if (Soul.Source == BlueMode)
            {
                KeyboardMovement(Key.S);
            }
            if (Keyboard.IsKeyDown(Key.A) || Keyboard.IsKeyDown(Key.Left))
            {
                KeyboardMovement(Key.A);
            }
            if (Keyboard.IsKeyDown(Key.S) || Keyboard.IsKeyDown(Key.Down))
            {
                KeyboardMovement(Key.S);
            }
            if (Keyboard.IsKeyDown(Key.D) || Keyboard.IsKeyDown(Key.Right))
            {
                KeyboardMovement(Key.D);
            }
            obstaclePositionUpdate();
        }
        class Obstacle
        {
            static Random random = new();
            public int height = random.Next(50, 150);
            public int width = 10;
            static string[] PossiblePositions = new string[]
            {
                "Top", "Bottom",
            };
            public string position = PossiblePositions[random.Next(0, PossiblePositions.Length)];
            public bool right = true;
        }
        DispatcherTimer TimeControl = new();
        Obstacle obstacle = new();
        public void GameLogic()
        {
            Soul.Source = BlueMode;
            foreach (Rectangle rectangle in RectangleContainer.Children)
            {
                string Type = Convert.ToString(rectangle.GetType());
                if (Type == "rectangle")
                {
                    obstacle = new();
                    rectangle.Width = obstacle.width;
                    rectangle.MinWidth = obstacle.width;
                    rectangle.MaxWidth = obstacle.width;
                    rectangle.Height = obstacle.height;
                    rectangle.MinHeight = obstacle.height;
                    rectangle.MaxHeight = obstacle.height;
                }
            }
            TimeControl.Tick += new EventHandler(GameControl);
            TimeControl.Interval = new TimeSpan(100000);
            TimeControl.Start();
        }
        public void obstaclePositionUpdate()
        {
            foreach(Rectangle rectangle in RectangleContainer.Children)
            {
                double leftMargin = rectangle.Margin.Left;
                double topMargin = rectangle.Margin.Top;
                double rightMargin = rectangle.Margin.Right;
                double bottomMargin = rectangle.Margin.Bottom;
                if (obstacle.position == "Bottom")
                {
                    bottomMargin = 10;
                    topMargin = FightBox.ActualHeight - 10 - rectangle.Height;
                }
                else if (obstacle.position == "Top")
                {
                    topMargin = 10;
                    bottomMargin = FightBox.ActualHeight - 10 - rectangle.Height;
                }
                if (obstacle.right)
                {
                    if (rightMargin <= 10)
                    {
                        leftMargin -= 5;
                        rightMargin += 5;
                        obstacle = new Obstacle();
                        obstacle.right = false;
                        rectangle.Width = obstacle.width;
                        rectangle.MinWidth = obstacle.width;
                        rectangle.MaxWidth = obstacle.width;
                        rectangle.Height = obstacle.height;
                        rectangle.MinHeight = obstacle.height;
                        rectangle.MaxHeight = obstacle.height;
                    }
                    else
                    {
                        leftMargin += 5;
                        rightMargin -= 5;
                    }
                }
                else
                {
                    if (leftMargin <= 10)
                    {
                        leftMargin += 5;
                        rightMargin -= 5;
                        obstacle = new Obstacle();
                        obstacle.right = true;
                        rectangle.Width = obstacle.width;
                        rectangle.MinWidth = obstacle.width;
                        rectangle.MaxWidth = obstacle.width;
                        rectangle.Height = obstacle.height;
                        rectangle.MinHeight = obstacle.height;
                        rectangle.MaxHeight = obstacle.height;
                    }
                    else
                    {
                        leftMargin -= 5;
                        rightMargin += 5;
                    }
                }
                rectangle.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
            }
        }
    }
}
