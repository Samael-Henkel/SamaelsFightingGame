﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FightingGameWPF3._0
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void Movement(object sender, RoutedEventArgs e)
        {
            double leftMargin = Soul.Margin.Left;
            double topMargin = Soul.Margin.Top;
            double rightMargin = Soul.Margin.Right;
            double bottomMargin = Soul.Margin.Bottom;
            Button clickedButton = sender as Button;
            string direction = Convert.ToString(clickedButton.Content);
            if (direction == "↑")
            {
                topMargin -= 1;
                bottomMargin += 1;
            }
            else if (direction == "↓")
            {
                topMargin += 1;
                bottomMargin -= 1;
            }
            else if (direction == "→")
            {
                leftMargin += 1;
                rightMargin -= 1;
            }
            else if (direction == "←")
            {
                leftMargin -= 1;
                rightMargin += 1;
            }
            Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
        }
        public void KeyboardMovement(object sender, KeyEventArgs e)
        {
            double leftMargin = Soul.Margin.Left;
            double topMargin = Soul.Margin.Top;
            double rightMargin = Soul.Margin.Right;
            double bottomMargin = Soul.Margin.Bottom;
            if(e.Key == Key.W || e.Key == Key.Up)
            {
                topMargin -= 5;
                bottomMargin += 5;
                if (topMargin < 10)
                {
                    topMargin = 10;
                    bottomMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                }
            }
            else if (e.Key == Key.S || e.Key == Key.Down)
            {
                topMargin += 5;
                bottomMargin -= 5;
                if (bottomMargin < 10)
                {
                    bottomMargin = 10;
                    topMargin = FightBox.ActualHeight - 10 - Soul.ActualHeight;
                }
            }
            if (e.Key == Key.A || e.Key == Key.Left)
            {
                leftMargin -= 5;
                rightMargin += 5;
                if (leftMargin < 10)
                {
                    leftMargin = 10;
                    rightMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                }
            } else if (e.Key == Key.D || e.Key == Key.Right)
            {
                leftMargin += 5;
                rightMargin -= 5;
                if (rightMargin < 10)
                {
                    rightMargin = 10;
                    leftMargin = FightBox.ActualWidth - 10 - Soul.ActualWidth;
                }
            }
            Soul.Margin = new Thickness(leftMargin, topMargin, rightMargin, bottomMargin);
            e.Handled = true;
        }
    }
}
